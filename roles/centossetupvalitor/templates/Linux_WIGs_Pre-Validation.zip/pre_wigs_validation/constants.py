from pre_wigs_validation.enums import ValidationResult, Colors

COLOR_MAP = {
    ValidationResult.PASS: Colors.PASS,
    ValidationResult.FAIL: Colors.FAIL,
    ValidationResult.ERROR: Colors.ERROR,
    ValidationResult.NOT_RUN: Colors.NOT_RUN,
}
