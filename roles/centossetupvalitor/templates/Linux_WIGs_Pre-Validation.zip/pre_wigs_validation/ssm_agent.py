import shutil
import subprocess

from pre_wigs_validation.enums import ValidationEnforcement, ValidationResult
from pre_wigs_validation.instance import ValidationInstance
from pre_wigs_validation.dataclasses import ValidationOutput
from pre_wigs_validation.utils import check_validation_config


class SSMAgent:
    """Validate that SSM Agent is installed and running on the instance."""

    # TODO exhaustively check service managers (status, service, systemctl)
    # TODO deep dive into return codes of all subprocesses
    validation = "SSM Agent"
    enforcement = ValidationEnforcement.REQUIRED

    @classmethod
    def validate(
        cls, *, enabled: bool = True, instance: ValidationInstance
    ) -> ValidationOutput:

        """
        Parameters:
        enabled (bool): whether or not to run this validation function
        instance (ValidationInstance): the instance object being validated

        Returns:
        ValidationOutput: output of validation
        """

        if not enabled:
            return ValidationOutput(
                validation=cls.validation,
                result=ValidationResult.NOT_RUN,
                enforcement=cls.enforcement,
            )

        fail_not_installed = "SSM Agent not installed"
        fail_not_running = "SSM Agent installed, but not running"
        error_message = "Unable to validate due to unsupported environment"
        v_error_systemctl = "Command 'systemctl' not in PATH"
        v_error_status = "Command 'status' not in PATH"
        config = check_validation_config(
            default_params=cls.validate.__kwdefaults__, local_params=locals()
        )

        if instance.major_version == "7" and (
            instance.distribution == "centos" or instance.distribution == "rhel"
        ):
            if shutil.which("systemctl") is None:
                return ValidationOutput(
                    validation=cls.validation,
                    result=ValidationResult.ERROR,
                    enforcement=cls.enforcement,
                    config=config,
                    message=error_message,
                    verbose_message=v_error_systemctl,
                )

            try:
                proc = subprocess.run(
                    ["systemctl", "status", "amazon-ssm-agent"], check=True
                )
            except subprocess.CalledProcessError:
                return ValidationOutput(
                    validation=cls.validation,
                    result=ValidationResult.FAIL,
                    enforcement=cls.enforcement,
                    config=config,
                    message=fail_not_installed,
                )

            try:
                subprocess.run(
                    ["systemctl", "is-active", "amazon-ssm-agent"], check=True
                )
                return ValidationOutput(
                    validation=cls.validation,
                    result=ValidationResult.PASS,
                    enforcement=cls.enforcement,
                    config=config,
                )
            except subprocess.CalledProcessError:
                return ValidationOutput(
                    validation=cls.validation,
                    result=ValidationResult.FAIL,
                    enforcement=cls.enforcement,
                    config=config,
                    message=fail_not_running,
                )

        elif instance.distribution == "rhel" or instance.distribution == "amzn":
            if shutil.which("status") is None:
                return ValidationOutput(
                    validation=cls.validation,
                    result=ValidationResult.ERROR,
                    enforcement=cls.enforcement,
                    config=config,
                    message=error_message,
                    verbose_message=v_error_status,
                )

            try:
                proc = subprocess.run(
                    ["status", "amazon-ssm-agent"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    check=True,
                )
            except subprocess.CalledProcessError:
                return ValidationOutput(
                    validation=cls.validation,
                    result=ValidationResult.FAIL,
                    enforcement=cls.enforcement,
                    config=config,
                    message=fail_not_installed,
                )
            if "running" not in proc.stdout.decode("utf-8"):
                return ValidationOutput(
                    validation=cls.validation,
                    result=ValidationResult.FAIL,
                    enforcement=cls.enforcement,
                    config=config,
                    message=fail_not_running,
                )
            return ValidationOutput(
                validation=cls.validation,
                result=ValidationResult.PASS,
                enforcement=cls.enforcement,
                config=config,
            )

        return ValidationOutput(
            validation=cls.validation,
            result=ValidationResult.ERROR,
            enforcement=cls.enforcement,
            config=config,
            message=error_message,
        )
