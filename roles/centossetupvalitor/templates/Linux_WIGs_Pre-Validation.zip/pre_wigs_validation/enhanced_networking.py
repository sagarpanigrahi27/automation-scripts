import shutil
import subprocess

from pre_wigs_validation.enums import ValidationEnforcement, ValidationResult
from pre_wigs_validation.instance import ValidationInstance
from pre_wigs_validation.dataclasses import ValidationOutput
from pre_wigs_validation.utils import check_validation_config


class EnhancedNetworking:
    """Validate that Enhanced Networking drivers are installed and enabled."""

    # TODO check version of drivers
    validation = "Enhanced Networking"
    enforcement = ValidationEnforcement.RECOMMENDED

    @classmethod
    def validate(
        cls, *, interface: int = 0, enabled: bool = True, instance: ValidationInstance
    ) -> ValidationOutput:

        """
        Parameters:
        interface (int): the network interface on which to search for ENA drivers
        enabled (bool): whether or not to run this validation function
        instance (ValidationInstance): the instance object being validated

        Returns:
        ValidationOutput: output of validation
        """

        if not enabled:
            return ValidationOutput(
                validation=cls.validation,
                result=ValidationResult.NOT_RUN,
                enforcement=cls.enforcement,
            )
        pass_message = "Enhanced Networking drivers enabled"
        fail_not_installed = (
            "Enhanced Networking drivers not found," " must be installed and enabled"
        )
        fail_not_enabled = (
            "Enhanced Networking drivers installed,"
            f" but not enabled on interface eth{interface}"
        )
        error_message = "Unable to validate due to unsupported environment"
        v_error_modinfo = "Command 'modinfo' not in PATH"
        v_error_ethtool = "Command 'ethtool' not in PATH"
        v_error_interface = (
            f"Error inspecting network interface eth{interface}."
            " May not be a valid interface."
        )
        config = check_validation_config(
            default_params=cls.validate.__kwdefaults__, local_params=locals()
        )

        if shutil.which("modinfo") is None:
            return ValidationOutput(
                validation=cls.validation,
                result=ValidationResult.ERROR,
                enforcement=cls.enforcement,
                config=config,
                message=error_message,
                verbose_message=v_error_modinfo,
            )

        try:
            proc_modinfo = subprocess.run(
                ["modinfo", "ena"],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except subprocess.CalledProcessError as error:
            return ValidationOutput(
                validation=cls.validation,
                result=ValidationResult.FAIL,
                enforcement=cls.enforcement,
                config=config,
                message=fail_not_installed,
                verbose_message=str(error),
            )

        if shutil.which("ethtool") is None:
            return ValidationOutput(
                validation=cls.validation,
                result=ValidationResult.ERROR,
                enforcement=cls.enforcement,
                config=config,
                message=error_message,
                verbose_message=v_error_ethtool,
            )

        try:
            proc_ethtool = subprocess.run(
                ["ethtool", "-i", f"eth{interface}"],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                check=True,
            )
        except subprocess.CalledProcessError:
            return ValidationOutput(
                validation=cls.validation,
                result=ValidationResult.ERROR,
                enforcement=cls.enforcement,
                config=config,
                message=error_message,
                verbose_message=v_error_interface,
            )
        if "driver: ena" not in proc_ethtool.stdout.decode("utf-8"):
            return ValidationOutput(
                validation=cls.validation,
                result=ValidationResult.FAIL,
                enforcement=cls.enforcement,
                config=config,
                message=fail_not_enabled,
            )

        return ValidationOutput(
            validation=cls.validation,
            result=ValidationResult.PASS,
            enforcement=cls.enforcement,
            config=config,
            message=pass_message,
        )
